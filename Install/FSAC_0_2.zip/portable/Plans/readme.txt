Generated MSFS flight plans will be placed in here.

File format is:

ICAO_to_ICAO_yyyymmdd_hhmmss.txt